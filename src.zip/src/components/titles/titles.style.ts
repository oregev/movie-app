import styled from 'styled-components';

export const StyledH2 = styled.h2`
  color: white;
`;

export const StyledH4 = styled.h4`
  color: white;
`;

export const StyledH6 = styled.h6`
  color: blue;
`;
