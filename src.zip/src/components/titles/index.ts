export { H2Title } from './H2Title';
export { H4Title } from './H4Title';
export { H6Title } from './H6Title';
