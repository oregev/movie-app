/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_MOVIE_API_URL: string;
  readonly VITE_MOVIE_API_KEY: string;
}
