import styled from 'styled-components';

export const NotFoundContainer = styled.div`
  padding: 20px;

  display: flex;
  justify-content: center;
  align-items: center;
`;

export const NotFoundTitle = styled.h2``;
