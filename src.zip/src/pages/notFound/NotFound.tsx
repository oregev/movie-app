import * as S from './NotFound.style';

export const NotFound = (): JSX.Element => (
  <S.NotFoundContainer>
    <S.NotFoundTitle>NotFound</S.NotFoundTitle>
  </S.NotFoundContainer>
);
