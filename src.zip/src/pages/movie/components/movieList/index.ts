export { MovieList } from './MovieList';
export type { IMovies } from './MovieList.types';
