export { MovieDetails } from './MovieDetails';
export type { IMovie } from './MovieDetails.types';
