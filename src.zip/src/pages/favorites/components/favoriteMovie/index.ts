export { FavoriteMovie } from './FavoriteMovie';
