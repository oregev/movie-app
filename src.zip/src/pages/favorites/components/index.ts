export { FavoriteMovie } from './favoriteMovie';
