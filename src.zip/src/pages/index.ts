export { Movie } from './movie/Movie';
export { Favorites } from './favorites/Favorites';
export { NotFound } from './notFound/NotFound';
